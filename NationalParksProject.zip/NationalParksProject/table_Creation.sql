CREATE TABLE `desposit_national_parks`.`Visitor_Centers` ( 
	`Park_ID` INT(2) NOT NULL , `VC_Name` VARCHAR(100) NOT NULL , 
	`VC_Street` VARCHAR(100) NOT NULL , `VC_Town` VARCHAR(100) NOT NULL , 
	`VC_State` VARCHAR(30) NOT NULL , 
	`VC_Zip` INT(5) NOT NULL ) ENGINE = MyISAM;
	
	
CREATE TABLE `desposit_national_parks`.`Event` ( `Event_ID` INT(3) NOT NULL , `Event_Title` VARCHAR(30) NOT NULL , `Event_Desc` VARCHAR(300) NULL DEFAULT NULL , `Event_Address` VARCHAR(100) NULL DEFAULT NULL , `Event_Town` VARCHAR(100) NULL DEFAULT NULL , `Event_State` VARCHAR(30) NOT NULL , PRIMARY KEY (`Event_ID`) ) ENGINE = MyISAM;